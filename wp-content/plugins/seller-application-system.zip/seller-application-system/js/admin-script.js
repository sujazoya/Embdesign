jQuery(document).ready(function($) {
    // Add any admin JS functionality here if needed
});