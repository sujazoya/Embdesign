<?php
/*
Plugin Name: WooCommerce Seller Upload
Description: Sellers can submit WooCommerce products with downloadable files.
Version: 3.1
Author: Your Name
*/

if (!defined('ABSPATH')) exit;

// Enqueue CSS and JS only when shortcode is used
add_action('wp_enqueue_scripts', 'wcsu_enqueue_assets');
function wcsu_enqueue_assets() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'product_submission_form')) {
        // Enqueue CSS
        wp_enqueue_style(
            'wcsu-style', 
            plugin_dir_url(__FILE__) . 'style.css',
            [],
            filemtime(plugin_dir_path(__FILE__) . 'style.css')
        );

        // Enqueue dummy JS handle for localization
        wp_enqueue_script(
            'wcsu-ajax',
            plugin_dir_url(__FILE__) . 'wcsu-ajax.js',
            ['jquery'],
            filemtime(plugin_dir_path(__FILE__) . 'wcsu-ajax.js'),
            true
        );

        // Localize Ajax URL
        wp_localize_script('wcsu-ajax', 'wcsu_ajax', [
            'ajaxurl' => admin_url('admin-ajax.php')
        ]);
    }
}

// Handle file upload with extension validation
function wcsu_handle_file_upload($file_field, $post_id) {
    if (!empty($_FILES[$file_field]['name'])) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $file_name = $_FILES[$file_field]['name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        $allowed_extensions = [
            'emb'     => ['emb'],
            'emb_e4'  => ['emb'],
            'emb_w6'  => ['emb'],
            'dst'     => ['dst'],
            'all_zip' => ['zip'],
            'other'   => [] // allow anything
        ];

        if (!empty($allowed_extensions[$file_field]) && !in_array($file_ext, $allowed_extensions[$file_field])) {
            return false;
        }

        $file_id = media_handle_upload($file_field, $post_id);
        if (!is_wp_error($file_id)) return $file_id;
    }
    return false;
}

// Shortcode: Product Submission Form
add_shortcode('product_submission_form', function () {
    if (!is_user_logged_in()) return '<p>Please <a href="' . wp_login_url() . '">log in</a> to submit a product.</p>';

    ob_start();

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['wcsu_submit'])) {
        $user_id = get_current_user_id();
        $title = sanitize_text_field($_POST['product_title']);
        $desc = sanitize_textarea_field($_POST['product_desc']);
        $price = floatval($_POST['price']);

        $post_id = wp_insert_post([
            'post_title'   => $title,
            'post_content' => $desc,
            'post_status'  => 'publish',
            'post_type'    => 'product',
            'post_author'  => $user_id,
        ]);

        if ($post_id) {
            update_post_meta($post_id, '_price', $price);
            update_post_meta($post_id, '_regular_price', $price);
            wp_set_object_terms($post_id, 'simple', 'product_type');

            $custom_fields = ['design_code', 'stitches', 'area', 'height', 'width', 'formats', 'needle'];
            foreach ($custom_fields as $field) {
                if (!empty($_POST[$field])) {
                    update_post_meta($post_id, $field, sanitize_text_field($_POST[$field]));
                }
            }

            if (!empty($_POST['category'])) {
                $cat_id = (int) $_POST['category'];
                $selected_cat = get_term_by('id', $cat_id, 'product_cat');
                
                if ($selected_cat->name === 'Bundles' && !empty($_POST['subcategory'])) {
                    $subcat_id = (int) $_POST['subcategory'];
                    wp_set_post_terms($post_id, [$subcat_id], 'product_cat');
                } else {
                    wp_set_post_terms($post_id, [$cat_id], 'product_cat');
                }
            }

            // Process tags
            if (!empty($_POST['product_tags'])) {
                $tags = array_map('intval', (array)$_POST['product_tags']);
                $valid_tags = [];
                
                foreach ($tags as $tag_id) {
                    if (term_exists($tag_id, 'product_tag')) {
                        $valid_tags[] = $tag_id;
                    }
                }
                
                if (!empty($valid_tags)) {
                    wp_set_object_terms($post_id, $valid_tags, 'product_tag');
                }
            } else {
                wp_set_object_terms($post_id, [], 'product_tag');
            }

            $thumb_id = wcsu_handle_file_upload('gallery', $post_id);
            if ($thumb_id) set_post_thumbnail($post_id, $thumb_id);

            $file_fields = ['dst', 'all_zip', 'emb_e4', 'emb_w6', 'emb'];
            $file_ids = [];
            foreach ($file_fields as $field) {
                $file_id = wcsu_handle_file_upload($field, $post_id);
                if ($file_id) $file_ids[$field] = $file_id;
            }
            update_post_meta($post_id, 'wcsu_files', $file_ids);

            wp_redirect($price == 0 ? site_url("/download-product/?product_id=$post_id") : get_permalink($post_id));
            exit;
        }
    }
    ?>

    <div class="wcsu-form-wrapper">
        <form method="post" enctype="multipart/form-data" class="wcsu-form">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                <h2 style="margin: 0;">✨ Submit Your EmbDesign ✨</h2>
                <a href="https://embdesign.shop/how-to-upload/" 
                   target="_blank"
                   style="display: inline-flex; 
                          align-items: center; 
                          justify-content: center;
                          width: 70px; 
                          height: 90px;
                          background-color: #FFD700;
                          color: white;
                          border-radius: 4px;
                          font-family: Arial, sans-serif;
                          text-decoration: none;
                          font-weight: bold;
                          font-size: 76px;
                          transition: all 0.3s ease;">
                    ﹖
                </a>
            </div>
        
            <label>Design Pictures:</label>
            <input type="file" name="gallery" accept="image/*">
             <label>Design Type (Category):</label>
            <select name="category" id="main_category" onchange="toggleSubcategory()">
                <?php foreach (get_terms(['taxonomy' => 'product_cat', 'hide_empty' => false, 'parent' => 0]) as $term): ?>
                    <option value="<?= esc_attr($term->term_id) ?>" <?php selected($_POST['category'] ?? '', $term->term_id) ?>><?= esc_html($term->name) ?></option>
                <?php endforeach; ?>
            </select>
            
            <div id="subcategory_field" style="display: none;">
                <label>Bundle Subcategory:</label>
                <select name="subcategory" id="subcategory">
                    <?php 
                    $bundles_cat = get_term_by('name', 'Bundles', 'product_cat');
                    if ($bundles_cat) {
                        $subcategories = get_terms([
                            'taxonomy' => 'product_cat',
                            'hide_empty' => false,
                            'parent' => $bundles_cat->term_id
                        ]);
                        foreach ($subcategories as $subcat): ?>
                            <option value="<?= esc_attr($subcat->term_id) ?>" <?php selected($_POST['subcategory'] ?? '', $subcat->term_id) ?>><?= esc_html($subcat->name) ?></option>
                        <?php endforeach;
                    }
                    ?>
                </select>
            </div>
            
            <div id="file-upload-fields" class="wcsu-upload-grid" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; font-size: 12px;">
                <!-- DST Upload -->
                <div style="display: flex; flex-direction: column; justify-content: space-between; min-height: 100px; border: 1px solid #ccc; padding: 6px; border-radius: 6px;">
                    <div>
                        <label style="margin-bottom: 4px;">DST:</label><br>
                        <label for="dst-file" style="background: #f0f0f0; border: 1px solid #aaa; padding: 4px 8px; cursor: pointer; display: inline-block; border-radius: 4px;">Choose DST File</label>
                        <input type="file" id="dst-file" name="dst" accept=".dst" onchange="updateFileName(this, 'dst-status')" style="display: none;">
                    </div>
                    <div id="dst-status" style="font-size: 11px; color: green; margin-top: 4px;">No file chosen</div>
                </div>

                <!-- EMB E4 Upload -->
                <div style="display: flex; flex-direction: column; justify-content: space-between; min-height: 100px; border: 1px solid #ccc; padding: 6px; border-radius: 6px;">
                    <div>
                        <label style="margin-bottom: 4px;">EMB E4 / EMB:</label><br>
                        <label for="emb-e4-file" style="background: #f0f0f0; border: 1px solid #aaa; padding: 4px 8px; cursor: pointer; display: inline-block; border-radius: 4px;">Choose EMB E4</label>
                        <input type="file" id="emb-e4-file" name="emb_e4" accept=".emb" multiple onchange="updateFileName(this, 'emb-e4-status')" style="display: none;">
                    </div>
                    <div id="emb-e4-status" style="font-size: 11px; color: green; margin-top: 4px;">No file chosen</div>
                </div>

                <!-- EMB W6 Upload -->
                <div style="display: flex; flex-direction: column; justify-content: space-between; min-height: 100px; border: 1px solid #ccc; padding: 6px; border-radius: 6px;">
                    <div>
                        <label style="margin-bottom: 4px;">EMB W6:</label><br>
                        <label for="emb-w6-file" style="background: #f0f0f0; border: 1px solid #aaa; padding: 4px 8px; cursor: pointer; display: inline-block; border-radius: 4px;">Choose EMB W6</label>
                        <input type="file" id="emb-w6-file" name="emb_w6" accept=".emb" multiple onchange="updateFileName(this, 'emb-w6-status')" style="display: none;">
                    </div>
                    <div id="emb-w6-status" style="font-size: 11px; color: green; margin-top: 4px;">No file chosen</div>
                </div>
            </div>

            <script>
            function updateFileName(input, targetId) {
                const statusDiv = document.getElementById(targetId);
                if (input.files.length > 0) {
                    const names = Array.from(input.files).map(file => file.name).join(', ');
                    statusDiv.textContent = names;
                } else {
                    statusDiv.textContent = 'No file chosen';
                }
            }
            </script>

            <input name="product_title" required placeholder="Design Name" value="<?php echo esc_attr($_POST['product_title'] ?? '') ?>">
            <textarea name="product_desc" required placeholder="Description"><?php echo esc_textarea($_POST['product_desc'] ?? '') ?></textarea>
            <input name="area" placeholder="Machine Area" value="<?php echo esc_attr($_POST['area'] ?? '') ?>">
            <input name="stitches" placeholder="Stitches" value="<?php echo esc_attr($_POST['stitches'] ?? '') ?>">
            
            <div id="dimension-fields">
                <input name="height" placeholder="Height (MM)" type="number" step="0.1" value="<?php echo esc_attr($_POST['height'] ?? '') ?>">
                <input name="width" placeholder="Width (MM)" type="number" step="0.1" value="<?php echo esc_attr($_POST['width'] ?? '') ?>">
            </div>
            
            <input name="formats" placeholder="Design Formats (emb , dst)" value="<?php echo esc_attr($_POST['formats'] ?? 'EMB,DST'); ?>">
            <input name="needle" placeholder="Needle" value="<?php echo esc_attr($_POST['needle'] ?? '') ?>">
            <input name="price" type="number" min="0" step="0.01" required placeholder="Price" value="<?php echo esc_attr($_POST['price'] ?? '') ?>">

            <div id="zip-upload-field" class="wcsu-upload-grid">
                <div><label>Bundle (Zip):</label><input type="file" name="all_zip" accept=".zip"></div>
            </div>

            <div class="wcsu-form-field">
                <label for="product_tags">Design Tags (What includes)</label>
                
                <div class="tags-dropdown-container">
                    <button type="button" class="tags-dropdown-button" onclick="toggleTagsDropdown()">
                        Select Tags ▼
                    </button>
                    <div class="tags-dropdown-content" style="display: none;">
                        <?php
                        $all_tags = get_terms([
                            'taxonomy' => 'product_tag',
                            'hide_empty' => false,
                            'orderby' => 'name',
                        ]);

                        $selected_tags = isset($_POST['product_tags']) ? array_map('intval', (array)$_POST['product_tags']) : [];
                        ?>
                        
                        <div class="tags-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(100px, 1fr)); gap: 5px; padding: 10px; background-color: #f9f9f9; border: 1px solid #ddd; border-radius: 4px;">
                            <?php foreach ($all_tags as $tag) : ?>
                                <div class="tag-item" style="margin: 2px 0;">
                                    <input type="checkbox" 
                                           name="product_tags[]" 
                                           id="product_tag_<?php echo esc_attr($tag->term_id); ?>" 
                                           value="<?php echo esc_attr($tag->term_id); ?>"
                                           <?php checked(in_array($tag->term_id, $selected_tags)); ?> />
                                    <label for="product_tag_<?php echo esc_attr($tag->term_id); ?>" style="margin-left: 5px;">
                                        <?php echo esc_html($tag->name); ?>
                                    </label>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>

            <button type="submit" name="wcsu_submit">🚀 Submit Design</button>
        </form>
    </div>

    <script>
    function toggleTagsDropdown() {
        var dropdown = document.querySelector('.tags-dropdown-content');
        var button = document.querySelector('.tags-dropdown-button');
        
        if (dropdown.style.display === 'none' || dropdown.style.display === '') {
            dropdown.style.display = 'block';
            button.innerHTML = 'Select Tags ▲';
        } else {
            dropdown.style.display = 'none';
            button.innerHTML = 'Select Tags ▼';
        }
    }

    function toggleSubcategory() {
        var mainCategory = document.getElementById('main_category');
        var subcategoryField = document.getElementById('subcategory_field');
        var fileUploadFields = document.getElementById('file-upload-fields');
        var dimensionFields = document.getElementById('dimension-fields');
        var zipUploadField = document.getElementById('zip-upload-field');
        var selectedOption = mainCategory.options[mainCategory.selectedIndex].text;
        
        if (selectedOption === 'Bundles') {
            subcategoryField.style.display = 'block';
            fileUploadFields.style.display = 'none';
            dimensionFields.style.display = 'none';
            zipUploadField.style.display = 'block';
        } else {
            subcategoryField.style.display = 'none';
            fileUploadFields.style.display = 'grid';
            dimensionFields.style.display = 'block';
            zipUploadField.style.display = 'none';
        }
    }

    document.addEventListener('DOMContentLoaded', function() {
        toggleSubcategory();
    });
    </script>

    <style>
    .tags-dropdown-button {
        padding: 8px 15px;
        background-color: #f0f0f0;
        border: 1px solid #ddd;
        border-radius: 4px;
        cursor: pointer;
        font-size: 14px;
        width: 100%;
        text-align: left;
        margin-bottom: 5px;
    }

    .tags-dropdown-button:hover {
        background-color: #e0e0e0;
    }

    .tags-dropdown-content {
        position: relative;
        z-index: 1;
        max-height: 300px;
        overflow-y: auto;
        box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    }
    </style>

    <?php
    return ob_get_clean();
});

// Shortcode: Download Page
add_shortcode('product_download_page', function () {
    if (empty($_GET['product_id'])) return '<p>No product ID provided.</p>';
    $product_id = intval($_GET['product_id']);
    $price = floatval(get_post_meta($product_id, '_price', true));
    $user_id = get_current_user_id();

    $has_access = $price == 0;
    if (!$has_access && is_user_logged_in()) {
        $orders = wc_get_orders(['customer_id' => $user_id, 'status' => 'completed']);
        foreach ($orders as $order) {
            foreach ($order->get_items() as $item) {
                if ($item->get_product_id() == $product_id) {
                    $has_access = true;
                    break 2;
                }
            }
        }
    }

    if (!$has_access) return '<p>You must purchase this product to download files.</p>';

    $file_ids = get_post_meta($product_id, 'wcsu_files', true);
    if (empty($file_ids)) return '<p>No files found for this product.</p>';

    $output = "<h2>🎉 Download Product Files</h2>";
    foreach ($file_ids as $label => $id) {
        $url = wp_get_attachment_url($id);
        $name = basename(get_attached_file($id));
        $output .= "<p><a href='$url' download class='button'>Download $name</a></p>";
    }

    return $output;
});

// Add download links on WooCommerce Thank You page
add_action('woocommerce_thankyou', function ($order_id) {
    $order = wc_get_order($order_id);
    if (!$order) return;

    foreach ($order->get_items() as $item) {
        $pid = $item->get_product_id();
        $file_ids = get_post_meta($pid, 'wcsu_files', true);
        if (!empty($file_ids)) {
            echo "<h3>Download Files for: " . esc_html(get_the_title($pid)) . "</h3>";
            foreach ($file_ids as $label => $id) {
                $url = wp_get_attachment_url($id);
                $name = basename(get_attached_file($id));
                echo "<p><a href='$url' download class='button'>Download $name</a></p>";
            }
        }
    }
});

// Allow .emb and .dst MIME types
add_filter('upload_mimes', function ($mimes) {
    $mimes['emb'] = 'application/octet-stream';
    $mimes['dst'] = 'application/octet-stream';
    return $mimes;
});

// Force file extension recognition for .emb and .dst
add_filter('wp_check_filetype_and_ext', function($data, $file, $filename, $mimes) {
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    if ($ext === 'emb') {
        return [
            'ext' => 'emb',
            'type' => 'application/octet-stream',
            'proper_filename' => $filename,
        ];
    }
    if ($ext === 'dst') {
        return [
            'ext' => 'dst',
            'type' => 'application/octet-stream',
            'proper_filename' => $filename,
        ];
    }
    return $data;
}, 99, 4);

// Bypass WordPress file type restriction
add_filter('user_has_cap', function($allcaps, $caps, $args, $user) {
    if (!empty($args[0]) && $args[0] === 'upload_files') {
        $allcaps['unfiltered_upload'] = true;
    }
    return $allcaps;
}, 10, 4);

// DST Parser AJAX handler
add_action('wp_ajax_wcsu_parse_dst', 'wcsu_parse_dst_ajax_handler');
add_action('wp_ajax_nopriv_wcsu_parse_dst', 'wcsu_parse_dst_ajax_handler');

function wcsu_parse_dst_ajax_handler() {
    if (empty($_FILES['dst_file'])) {
        wp_send_json_error('No file uploaded');
    }

    $uploaded_file = $_FILES['dst_file'];
    $file_tmp_path = $uploaded_file['tmp_name'];
    $file_name = $uploaded_file['name'];

    $url = 'https://embroidery-parser.onrender.com/parse_embroidery';
    $curl = curl_init();

    $cfile = new CURLFile($file_tmp_path, 'application/octet-stream', $file_name);
    $post_data = ['file' => $cfile];

    curl_setopt_array($curl, [
        CURLOPT_URL => $url,
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POSTFIELDS => $post_data,
        CURLOPT_TIMEOUT => 20,
    ]);

    $response = curl_exec($curl);
    $error = curl_error($curl);
    curl_close($curl);

    if ($error) {
        wp_send_json_error("cURL error: $error");
    }

    $parsed = json_decode($response, true);
    if (json_last_error() !== JSON_ERROR_NONE || empty($parsed['success'])) {
        wp_send_json_error($parsed['error'] ?? 'Failed to parse response');
    }

    wp_send_json_success([
        'design_name'   => $parsed['design_name'] ?? '',
        'stitches'      => $parsed['stitches'] ?? '',
        'machine_area'  => $parsed['area'] ?? '',
        'height'        => $parsed['height'] ?? '',
        'width'         => $parsed['width'] ?? '',
        'design_formats'=> $parsed['formats'] ?? '',
        'needles'       => $parsed['needle'] ?? '',
    ]);
}

// Auto-Fill Frontend Script for DST Upload
add_action('wp_footer', function () {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'product_submission_form')) {
        ?>
        <script>
        jQuery(document).ready(function($) {
            $('input[name="dst"]').on('change', function () {
                var input = this;
                if (!input.files.length) return;

                var formData = new FormData();
                formData.append('action', 'wcsu_parse_dst');
                formData.append('dst_file', input.files[0]);

                var $spinner = $('<span class="wcsu-loading">Parsing DST...</span>');
                $(input).after($spinner);

                $.ajax({
                    url: wcsu_ajax.ajaxurl,
                    type: 'POST',
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function (res) {
                        if (res.success) {
                            const d = res.data;
                            $('input[name="product_title"]').val(d.design_name);
                            $('input[name="stitches"]').val(d.stitches);
                            $('input[name="area"]').val(d.machine_area);
                            $('input[name="height"]').val(d.height);
                            $('input[name="width"]').val(d.width);
                            $('input[name="formats"]').val(d.design_formats);
                            $('input[name="needle"]').val(d.needles);
                        } else {
                            alert("DST Parsing Failed: " + res.data);
                        }
                    },
                    error: function () {
                        alert("AJAX error parsing DST file.");
                    },
                    complete: function () {
                        $spinner.remove();
                    }
                });
            });
        });
        </script>
        <style>
        .wcsu-loading {
            color: #0073aa;
            margin-left: 10px;
            font-style: italic;
            font-size: 13px;
        }
        </style>
        <?php
    }
});